//link : https://api-ramdaniofficial.herokuapp.com
//apikey : Ramdaniofficial
//mohon maap apabila menemukan bug di apikey tersebut, mohon di maklumi.