module.exports.mess = {
	        regist: '─ 「 *NOT REGISTERED* 」 ─\n\n*ENGLISH*\n_YOU HAVE NOT REGISTERED ON THE BOTTOM OF I DECK, TYPE .verify FOR RUQYAH_\n\n*INDONESIA*\n_LUH BELUM DAFTAR DI BOT GUA DEX, KETIK .daftar UNTUK DI RUQYAH_',
		    dewasa: '─ 「 *WARNING* 」 ─\n\n*ENGLISH*\n_not allowed for minors, if you are an adult, please verify first, type .my18_\n\n*INDONESIA*\n_dilarang untuk anak di bawah umur, jika Anda sudah dewasa, silahkan verifikasi terlebih dahulu, ketik .saya18_',
		    waitregist: '*ENGLISH*\n_WAIT A MINUTE DECK_\n\n*INDONESIA*\n_TUNGGU SEBENTAR DEK_',
	        wait: '_Wait Process!..._',
			success: '_Done, don t forget to subscribe_ : https://youtube.com/channel/UCB157jomCne961WzYHpG4gg',
			wrongFormat: '_Format error, try again!_',
			error: {
				api: '_Error, apikey is not found!_',
				stick: '_Error, just try to send a picture!_',
				Iv: '_Error, try to give the correct link!_'
			},
			only: {
				group: '_Can only be used in groups!_',
				admin: '_Can only be used by admin!_',
				premium: '_Can only be used by premium users!_',
				owner: '_Can only be used by owner!_',
				Badmin: '_Can only be used if the bot is an admin!_',
			}
		}
