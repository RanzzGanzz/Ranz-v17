const topupdana = (prefix) => { 
	return `*HALLO KAK👋*
*PILIH DIBAWAH YA!!!*
� 5k
� 10k
� 20k
� 30k
� 40k
� 50k
� 60k
� 70k
� 80k
� 90k
� 100k
*minat? hub :* http://wa.me/${nomorowner}
`
}

exports.topupdana = topupdana