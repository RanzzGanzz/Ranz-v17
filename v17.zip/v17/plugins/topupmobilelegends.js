const topupmobilelegends = (prefix) => { 
	return `*HALLO KAK👋*
*PILIH DIBAWAH YA!!!*
*LIST DM ML*
*NO ILEGAL 100%*
2.500 = 3💎
5.500 = 12💎
10.500 = 28💎
12.500 = 36💎
19.500 = 59💎
23.300 = 74💎
26.400 = 85💎
50.900 = 170💎
54.200 = 185💎
64.100 = 222💎
89.600 = 296💎
105.200 = 370💎
165.400 = 568💎
350.500 = 1159💎
1.354.800 = 4830💎
1.600.900 = 6050💎
Starlight Member = 240.400
Starlight Prem = 350.300
*minat? hub :* http://wa.me/${nomorowner}
`
}

exports.topupmobilelegends = topupmobilelegends