const topuppubg = (prefix) => { 
	return `*HALLO KAK👋*
*PILIH DIBAWAH YA!!!*
*LIST UC PUBG*
*NO ILEGAL*
- 🎟️60 = Rp14.000
- 🎟️120 = Rp28.000
- 🎟️240 = Rp56.000
*minat? hub :* http://wa.me/${nomorowner}
`
}

exports.topuppubg = topuppubg